import random
from art import logo, vs
from replit import clear
from game_data import data

# # make a function for returning details in format:


def info(player):
  name = player["name"]
  des = player["description"]
  country = player["country"]
  return f"{name}, a {des} from {country}"


# # make a function for game and make it repeat:
def play():
  print(logo)
  score = 0
  # game on
  game_on = True
  # computer will randomly pick 2 values
  A = random.choice(data)
  B = random.choice(data)

  while game_on == True:
    A = B
    B = random.choice(data)

    print(f"Compare A: {info(A)}.")
    print(vs)
    print(f"Against B: {info(B)}. ")

    ans = input("Who do you think has more followers?").lower()

    A_follower = A["follower_count"]
    B_follower = B["follower_count"]

    clear()
    print(logo)

    if A_follower > B_follower and ans == "a":
      score += 1
      print(f"You are right! Current score: {score}.")
    elif B_follower > A_follower and ans == "b":
      score += 1
      print(f"You are right! Current score: {score}.")
    else:
      game_on = False
      print(f"Sorry, you're wrong! Your score is {score}.")


play()

# # input of compare
# # compare function :
# #  compare values and input
# #  if input = compare: add 1 to score
# #     keep value B and pick next value C
# # else input != compare: print score
